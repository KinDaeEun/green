package ch17.service;


import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MailAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {
		Properties p = System.getProperties();
		p.put("mail.smtp.starttls.enable","true");
		p.put("mail.smtp.host", "smtp.naver.com");
		p.put("mail.smtp.auth","true");
		p.put("mail.smtp.port","587");
		p.put("mail.smtp.ssl.protocols","TLSv1.2");
		String to2 = request.getParameter("to");
		String subject = request.getParameter("subject");
		String msg = request.getParameter("msg");
		String myEmail = "andy200415@naver.com";
		Authenticator auth = new MyAuth();
		Session session = Session.getDefaultInstance(p,auth);
		MimeMessage mm = new MimeMessage(session);
		try {
			mm.setSentDate(new Date());
			InternetAddress from = new InternetAddress();
			from = new InternetAddress(myEmail);
			mm.setFrom(from);
			
			InternetAddress to = new InternetAddress(to2);
			mm.setRecipient(Message.RecipientType.TO, to);
			
			mm.setSubject(subject,"utf-8");
			mm.setText(msg,"utf-8");
			mm.setHeader("content-Type","tetxt/html");
			
			javax.mail.Transport.send(mm);
			request.setAttribute("msg", "보내기 성공");
		}catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg","보내기 실패 ㅠㅠ");
		}
		return "mailto";
	}
	

}
class MyAuth extends Authenticator{
	javax.mail.PasswordAuthentication account;
	public MyAuth() {
		String id="andy200415";
		String pw = "andy123321";
		account = new PasswordAuthentication(id, pw);
	}
	protected PasswordAuthentication getPasswordAuthentication() {
		return account;
	}
}